<?php
namespace local_courseprogressnotify\task;

defined('MOODLE_INTERNAL') || die();

use core\task\scheduled_task;
use local_courseprogressnotify\email_builder;
use local_courseprogressnotify\notification_log;

/**
 * Task to notify users on the second day of course about browser compatibility.
 */
class check_second_day_tasks extends scheduled_task {

    public function get_name() {
        return get_string('task_check_second_day_tasks', 'local_courseprogressnotify');
    }

    public function execute() {
        global $DB;
        
        mtrace('Running task: second day tasks notification (browser compatibility)');
        
        $customfieldshortname = get_config('local_courseprogressnotify', 'customfield_shortname');
        
        if (empty($customfieldshortname)) {
            mtrace('No custom field configured; skipping.');
            return;
        }
        
        mtrace("Using custom field: {$customfieldshortname}");

        $now = time();
        $yesterdaystart = usergetmidnight($now - DAYSECS);
        $yesterdayend = $yesterdaystart + DAYSECS;

        mtrace("Time window : " . userdate($yesterdaystart, '%Y-%m-%d %H:%M:%S') . " → " . userdate($yesterdayend, '%Y-%m-%d %H:%M:%S'));
        mtrace("Timestamps  : {$yesterdaystart} → {$yesterdayend}");
        mtrace("Server time : " . date('Y-m-d H:i:s T', $now));

        // Courses that started yesterday (second day is today)
        $courses = $DB->get_records_select('course', 
            'visible = 1 AND startdate >= :from AND startdate < :to', 
            [
                'from' => $yesterdaystart,
                'to' => $yesterdayend,
            ]
        );

        mtrace('  Visible courses in window (before custom field filter): ' . count($courses));

        if (empty($courses)) {
            mtrace('  No courses on their second day.');
            return;
        }

        // Filter courses based on custom field, logging reason for each exclusion.
        $enabled = [];
        foreach ($courses as $course) {
            $startreadable = userdate($course->startdate, '%Y-%m-%d %H:%M:%S');
            if ($this->is_course_enabled($course->id, $customfieldshortname)) {
                mtrace("  [ENABLED]  {$course->fullname} (startdate: {$startreadable} / {$course->startdate})");
                $enabled[] = $course;
            } else {
                mtrace("  [SKIPPED]  {$course->fullname} (startdate: {$startreadable} / {$course->startdate}) — custom field '{$customfieldshortname}' not set or not enabled");
            }
        }
        $courses = $enabled;

        if (empty($courses)) {
            mtrace('  Courses are on their second day but none have notifications enabled (check the custom field setting).');
            return;
        }

        $totalnotifs = 0;
        
        foreach ($courses as $course) {
            mtrace("  Course: {$course->fullname} (started: " . userdate($course->startdate, '%Y-%m-%d') . ")");
            
            $students = $this->get_course_students($course->id);
            if (empty($students)) {
                mtrace("    No students found.");
                continue;
            }
            
            $notified = 0;
            
            foreach ($students as $user) {
                if (notification_log::has_sent($user->id, $course->id, 'second_day_tasks')) {
                    mtrace("    ✓ Already sent to {$user->firstname} {$user->lastname} ({$user->email}) - skipping");
                    continue;
                }
                
                $placeholders = [];
                
                $sent = email_builder::send($user, $course, 'second_day', $placeholders, 'second_day_tasks');
                if ($sent) {
                    $notified++;
                    $totalnotifs++;
                }
            }
            
            mtrace("    Notified: {$notified}");
        }
        
        mtrace("Second day tasks check complete. Total notifications sent: {$totalnotifs}");
    }

    protected function get_course_students(int $courseid): array {
        global $DB;
        $sql = "SELECT DISTINCT u.*
                  FROM {user} u
                  JOIN {user_enrolments} ue ON ue.userid = u.id AND ue.status = 0
                  JOIN {enrol} e ON e.id = ue.enrolid AND e.courseid = :courseid AND e.status = 0
                  JOIN {role_assignments} ra ON ra.userid = u.id
                  JOIN {role} r ON r.id = ra.roleid AND r.archetype = 'student'
                  JOIN {context} ctx ON ctx.id = ra.contextid AND ctx.contextlevel = :ctxlevel AND ctx.instanceid = :courseid2
                 WHERE u.deleted = 0 AND u.suspended = 0";
        $params = ['courseid' => $courseid, 'courseid2' => $courseid, 'ctxlevel' => CONTEXT_COURSE];
        return $DB->get_records_sql($sql, $params);
    }

    /**
     * Check if notifications are enabled for a course via custom field.
     * @param int $courseid Course ID
     * @param string $customfieldshortname Custom field shortname from settings
     * @return bool True if notifications should be sent for this course
     */
    private function is_course_enabled($courseid, $customfieldshortname) {
        global $DB;
        
        $field = $DB->get_record('customfield_field', ['shortname' => $customfieldshortname]);
        if (!$field) {
            return false;
        }
        
        $data = $DB->get_record('customfield_data', [
            'fieldid' => $field->id,
            'instanceid' => $courseid
        ]);
        
        return $data && $data->value == 1;
    }
}
